function showNavbar()
{
    document.querySelector(".side-navbar").style.left="0"
}

function closeNavbar()
{
    document.querySelector(".side-navbar").style.left="-60%"
}